import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RedSeguraTest {
    @Test void rutaOriginalCuesta24(){
        var r=new DijkstraSolver().shortestPath(GraphFactory.create(),"S02","S08");
        assertEquals(24,r.cost());
        assertEquals(java.util.List.of("S02","S01","S07","S08"),r.path());
    }
    @Test void bloquearR16CambiaRuta(){
        MixedGraph g=GraphFactory.create();g.blockEdge("R16");
        var r=new DijkstraSolver().shortestPath(g,"S02","S08");
        assertEquals(24,r.cost());
        assertEquals(java.util.List.of("S02","S01","S09","S10","S08"),r.path());
    }
    @Test void verticeInexistente(){
        assertThrows(java.util.NoSuchElementException.class,()->GraphFactory.create().getVertex("S99"));
    }
    @Test void pesoInvalido(){
        assertThrows(IllegalArgumentException.class,()->new Edge("R","S1","S2",0,"",true));
    }
    @Test void avlPermaneceBalanceadoEnSecuenciaAscendente(){
        AvlTree t=new AvlTree();for(int i=1;i<=100;i++)t.insert(new Vertex(String.format("S%03d",i),"v","t"));
        assertTrue(t.height()<=7);
        assertNotNull(t.search("S050"));
    }
}

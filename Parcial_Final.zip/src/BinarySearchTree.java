import java.util.*;

public class BinarySearchTree {
    private static class Node { Vertex value; Node left,right; Node(Vertex v){value=v;} }
    private Node root;
    private int steps;
    public void insert(Vertex v){root=insert(root,v);}
    private Node insert(Node n,Vertex v){
        if(n==null)return new Node(v);
        int c=v.getId().compareTo(n.value.getId());
        if(c<0)n.left=insert(n.left,v); else if(c>0)n.right=insert(n.right,v);
        else throw new IllegalArgumentException("Clave duplicada: "+v.getId());
        return n;
    }
    public Vertex search(String id){
        steps=0; Node n=root;
        while(n!=null){steps++; int c=id.compareTo(n.value.getId()); if(c==0)return n.value; n=c<0?n.left:n.right;}
        return null;
    }
    public int getLastSearchSteps(){return steps;}
    public void delete(String id){root=delete(root,id);}
    private Node delete(Node n,String id){
        if(n==null)return null;
        int c=id.compareTo(n.value.getId());
        if(c<0)n.left=delete(n.left,id); else if(c>0)n.right=delete(n.right,id);
        else {
            if(n.left==null)return n.right; if(n.right==null)return n.left;
            Node min=n.right; while(min.left!=null)min=min.left;
            n.value=min.value; n.right=delete(n.right,min.value.getId());
        } return n;
    }
    public List<Vertex> inOrder(){List<Vertex> r=new ArrayList<>(); in(root,r,0); return r;}
    public List<Vertex> preOrder(){List<Vertex> r=new ArrayList<>(); in(root,r,1); return r;}
    public List<Vertex> postOrder(){List<Vertex> r=new ArrayList<>(); in(root,r,2); return r;}
    private void in(Node n,List<Vertex> r,int mode){
        if(n==null)return; if(mode==1)r.add(n.value); in(n.left,r,mode);
        if(mode==0)r.add(n.value); in(n.right,r,mode); if(mode==2)r.add(n.value);
    }
    public int height(){return height(root);}
    private int height(Node n){return n==null?0:1+Math.max(height(n.left),height(n.right));}
}

public class Vertex {
    private final String id, label, type;
    public Vertex(String id, String label, String type) {
        if (id == null || id.isBlank() || label == null || label.isBlank())
            throw new IllegalArgumentException("ID y etiqueta son obligatorios");
        this.id = id; this.label = label; this.type = type == null ? "" : type;
    }
    public String getId(){ return id; }
    public String getLabel(){ return label; }
    public String getType(){ return type; }
    @Override public String toString(){ return id + " - " + label; }
}

import java.util.*;

public class GraphRepresentations {
    private final List<Vertex> vertices;
    private final List<Edge> edges;
    public GraphRepresentations(MixedGraph graph){
        vertices=new ArrayList<>(graph.getVertices()); edges=new ArrayList<>(graph.getEdges());
    }
    public String adjacencyList(MixedGraph graph){
        StringBuilder s=new StringBuilder();
        for(Vertex v:vertices){
            s.append(v.getId()).append(": ");
            List<String> ns=new ArrayList<>();
            for(Edge e:graph.getOutgoing(v.getId())) ns.add(graph.opposite(e,v.getId())+"("+e.getWeight()+","+e.getId()+")");
            s.append(ns).append(System.lineSeparator());
        } return s.toString();
    }
    public int[][] adjacencyMatrix(){
        int n=vertices.size();int[][] m=new int[n][n];
        for(Edge e:edges){int a=index(e.getFrom()),b=index(e.getTo());m[a][b]=e.getWeight();if(!e.isDirected())m[b][a]=e.getWeight();}
        return m;
    }
    // Incidencia orientada: -1 origen, +1 destino; no dirigida: +1 en ambos extremos.
    public int[][] incidenceMatrix(){
        int[][] m=new int[vertices.size()][edges.size()];
        for(int j=0;j<edges.size();j++){Edge e=edges.get(j);int a=index(e.getFrom()),b=index(e.getTo());
            if(e.isDirected()){m[a][j]=-1;m[b][j]=1;}else{m[a][j]=1;m[b][j]=1;}
        }return m;
    }
    public List<String> vertexOrder(){return vertices.stream().map(Vertex::getId).toList();}
    public List<String> edgeOrder(){return edges.stream().map(Edge::getId).toList();}
    private int index(String id){for(int i=0;i<vertices.size();i++)if(vertices.get(i).getId().equals(id))return i;throw new IllegalArgumentException(id);}
    public static String matrixToString(int[][] m){StringBuilder s=new StringBuilder();for(int[] row:m)s.append(Arrays.toString(row)).append(System.lineSeparator());return s.toString();}
}

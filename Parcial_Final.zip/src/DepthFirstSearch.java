import java.util.*;

public class DepthFirstSearch {
    public List<String> traverse(MixedGraph g,String start){
        g.getVertex(start);Set<String> visited=new LinkedHashSet<>();List<String> order=new ArrayList<>();dfs(g,start,visited,order);return order;
    }
    private void dfs(MixedGraph g,String u,Set<String> visited,List<String> order){
        visited.add(u);order.add(u);
        for(Edge e:g.getOutgoing(u)){String v=g.opposite(e,u);if(!visited.contains(v))dfs(g,v,visited,order);}
    }
    // Componentes débiles: considera cada conexión como no dirigida solo para este análisis.
    public List<List<String>> weakComponents(MixedGraph g){
        Map<String,List<String>> adj=new LinkedHashMap<>();for(Vertex v:g.getVertices())adj.put(v.getId(),new ArrayList<>());
        for(Edge e:g.getEdges()){adj.get(e.getFrom()).add(e.getTo());adj.get(e.getTo()).add(e.getFrom());}
        Set<String> seen=new HashSet<>();List<List<String>> result=new ArrayList<>();
        for(String id:adj.keySet())if(!seen.contains(id)){List<String> comp=new ArrayList<>();Deque<String> st=new ArrayDeque<>();st.push(id);seen.add(id);
            while(!st.isEmpty()){String u=st.pop();comp.add(u);for(String v:adj.get(u))if(seen.add(v))st.push(v);}
            result.add(comp);
        }return result;
    }
}

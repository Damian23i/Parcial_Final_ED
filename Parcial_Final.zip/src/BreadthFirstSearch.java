import java.util.*;

public class BreadthFirstSearch {
    public List<String> traverse(MixedGraph g,String start){
        g.getVertex(start);Set<String> visited=new LinkedHashSet<>();Queue<String> q=new ArrayDeque<>();List<String> order=new ArrayList<>();
        visited.add(start);q.add(start);
        while(!q.isEmpty()){String u=q.remove();order.add(u);
            for(Edge e:g.getOutgoing(u)){String v=g.opposite(e,u);if(visited.add(v))q.add(v);}
        }return order;
    }
}

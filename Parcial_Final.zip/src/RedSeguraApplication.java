import java.util.*;

public class RedSeguraApplication {
    private static void print(String title,Object value){System.out.println("\n"+title+"\n"+value);}
    private static void showTreeRotations(){
        String[][] cases={{"LL","S30","S20","S10"},{"RR","S10","S20","S30"},{"LR","S30","S10","S20"},{"RL","S10","S30","S20"}};
        for(String[] c:cases){AvlTree t=new AvlTree();for(int i=1;i<c.length;i++)t.insert(new Vertex(c[i],c[i],"Demo"));
            System.out.println("Rotación "+c[0]+" demostrada insertando "+Arrays.toString(Arrays.copyOfRange(c,1,c.length))+"; altura final="+t.height());}
    }
    public static void main(String[] args){
        MixedGraph graph=GraphFactory.create();
        BinarySearchTree abb=new BinarySearchTree();AvlTree avl=new AvlTree();
        for(Vertex v:graph.getVertices()){abb.insert(v);avl.insert(v);}
        Scanner sc=new Scanner(System.in);
        while(true){
            System.out.println("\n===== REDSEGURA =====");
            System.out.println("1. Buscar Hospital en ABB y AVL");
            System.out.println("2. Demostrar rotaciones AVL");
            System.out.println("3. Mostrar representaciones del grafo");
            System.out.println("4. BFS desde S02");
            System.out.println("5. DFS desde S02 y componentes débiles");
            System.out.println("6. Dijkstra S02 a S08");
            System.out.println("7. Bloquear R16 y recalcular");
            System.out.println("8. Consultar vértice");
            System.out.println("9. Mostrar recorridos y altura ABB");
            System.out.println("0. Salir");
            System.out.print("Opción: ");String op=sc.nextLine().trim();
            try{
                switch(op){
                    case "1" -> {
                        String id="S05";Vertex a=abb.search(id),b=avl.search(id);
                        System.out.println("ABB: "+a+"; pasos="+abb.getLastSearchSteps());
                        System.out.println("AVL: "+b+"; pasos="+avl.getLastSearchSteps());
                    }
                    case "2" -> showTreeRotations();
                    case "3" -> {GraphRepresentations r=new GraphRepresentations(graph);
                        print("Lista de adyacencia",r.adjacencyList(graph));
                        print("Orden de vértices",r.vertexOrder());print("Matriz de adyacencia",GraphRepresentations.matrixToString(r.adjacencyMatrix()));
                        print("Orden de conexiones",r.edgeOrder());print("Matriz de incidencia",GraphRepresentations.matrixToString(r.incidenceMatrix()));}
                    case "4" -> print("BFS desde S02",new BreadthFirstSearch().traverse(graph,"S02"));
                    case "5" -> {DepthFirstSearch d=new DepthFirstSearch();print("DFS desde S02",d.traverse(graph,"S02"));print("Componentes débiles",d.weakComponents(graph));}
                    case "6" -> showRoute(graph);
                    case "7" -> {graph.blockEdge("R16");System.out.println("R16 bloqueada.");showRoute(graph);}
                    case "8" -> {System.out.print("ID del vértice: ");String id=sc.nextLine().trim();System.out.println(graph.getVertex(id));}
                    case "9" -> {print("ABB inOrder",abb.inOrder());print("ABB preOrder",abb.preOrder());print("ABB postOrder",abb.postOrder());print("Altura ABB",abb.height());print("Altura AVL",avl.height());}
                    case "0" -> {System.out.println("Hasta luego.");return;}
                    default -> System.out.println("Opción no válida.");
                }
            }catch(NoSuchElementException|IllegalArgumentException ex){System.out.println("Error controlado: "+ex.getMessage());}
        }
    }
    private static void showRoute(MixedGraph g){
        DijkstraSolver.Result r=new DijkstraSolver().shortestPath(g,"S02","S08");
        if(r.path().isEmpty())System.out.println("No existe ruta.");else System.out.println("Ruta: "+r.path()+" | costo: "+r.cost()+" minutos");
    }
}

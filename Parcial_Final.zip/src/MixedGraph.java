import java.util.*;

public class MixedGraph {
    private final Map<String,Vertex> vertices = new LinkedHashMap<>();
    private final Map<String,Edge> edges = new LinkedHashMap<>();
    private final Set<String> blocked = new HashSet<>();

    public void addVertex(Vertex v) {
        Objects.requireNonNull(v);
        if(vertices.putIfAbsent(v.getId(),v)!=null) throw new IllegalArgumentException("Vértice duplicado: "+v.getId());
    }
    public void addEdge(Edge e) {
        Objects.requireNonNull(e);
        if(edges.containsKey(e.getId())) throw new IllegalArgumentException("Conexión duplicada: "+e.getId());
        if(!vertices.containsKey(e.getFrom()) || !vertices.containsKey(e.getTo()))
            throw new IllegalArgumentException("Origen o destino inexistente");
        edges.put(e.getId(),e);
    }
    public Vertex getVertex(String id) {
        Vertex v=vertices.get(id); if(v==null) throw new NoSuchElementException("No existe el vértice: "+id); return v;
    }
    public Collection<Vertex> getVertices(){return Collections.unmodifiableCollection(vertices.values());}
    public Collection<Edge> getEdges(){return Collections.unmodifiableCollection(edges.values());}
    public List<Edge> getOutgoing(String id) {
        getVertex(id);
        List<Edge> out=new ArrayList<>();
        for(Edge e:edges.values()) if(!blocked.contains(e.getId()) &&
            (e.getFrom().equals(id) || (!e.isDirected() && e.getTo().equals(id)))) out.add(e);
        return out;
    }
    public String opposite(Edge e,String id) {
        if(e.getFrom().equals(id)) return e.getTo();
        if(!e.isDirected() && e.getTo().equals(id)) return e.getFrom();
        throw new IllegalArgumentException("La conexión no sale del vértice indicado");
    }
    public void blockEdge(String edgeId) {
        if(!edges.containsKey(edgeId)) throw new NoSuchElementException("No existe la conexión: "+edgeId);
        blocked.add(edgeId);
    }
    public void unblockEdge(String edgeId){blocked.remove(edgeId);}
    public boolean isBlocked(String edgeId){return blocked.contains(edgeId);}
}

public class AvlTree {
    private static class Node { Vertex value; Node left,right; int height=1; Node(Vertex v){value=v;} }
    private Node root;
    private int steps;
    private int h(Node n){return n==null?0:n.height;}
    private void update(Node n){n.height=1+Math.max(h(n.left),h(n.right));}
    private int balance(Node n){return n==null?0:h(n.left)-h(n.right);}
    private Node rotateRight(Node y){Node x=y.left, t=x.right; x.right=y; y.left=t; update(y);update(x);return x;}
    private Node rotateLeft(Node x){Node y=x.right,t=y.left;y.left=x;x.right=t;update(x);update(y);return y;}
    public void insert(Vertex v){root=insert(root,v);}
    private Node insert(Node n,Vertex v){
        if(n==null)return new Node(v);
        int c=v.getId().compareTo(n.value.getId());
        if(c<0)n.left=insert(n.left,v);else if(c>0)n.right=insert(n.right,v);
        else throw new IllegalArgumentException("Clave duplicada: "+v.getId());
        update(n); int b=balance(n);
        if(b>1 && v.getId().compareTo(n.left.value.getId())<0)return rotateRight(n);       // LL
        if(b<-1 && v.getId().compareTo(n.right.value.getId())>0)return rotateLeft(n);     // RR
        if(b>1 && v.getId().compareTo(n.left.value.getId())>0){n.left=rotateLeft(n.left);return rotateRight(n);} // LR
        if(b<-1 && v.getId().compareTo(n.right.value.getId())<0){n.right=rotateRight(n.right);return rotateLeft(n);} // RL
        return n;
    }
    public Vertex search(String id){steps=0;Node n=root;while(n!=null){steps++;int c=id.compareTo(n.value.getId());if(c==0)return n.value;n=c<0?n.left:n.right;}return null;}
    public int getLastSearchSteps(){return steps;}
    public void delete(String id){root=delete(root,id);}
    private Node delete(Node n,String id){
        if(n==null)return null;
        int c=id.compareTo(n.value.getId());
        if(c<0)n.left=delete(n.left,id);else if(c>0)n.right=delete(n.right,id);
        else {
            if(n.left==null)return n.right;if(n.right==null)return n.left;
            Node s=n.right;while(s.left!=null)s=s.left;n.value=s.value;n.right=delete(n.right,s.value.getId());
        }
        update(n);int b=balance(n);
        if(b>1 && balance(n.left)>=0)return rotateRight(n);
        if(b>1 && balance(n.left)<0){n.left=rotateLeft(n.left);return rotateRight(n);}
        if(b<-1 && balance(n.right)<=0)return rotateLeft(n);
        if(b<-1 && balance(n.right)>0){n.right=rotateRight(n.right);return rotateLeft(n);}
        return n;
    }
    public int height(){return h(root);}
}

public final class GraphFactory {
    private GraphFactory(){}
    public static MixedGraph create(){
        MixedGraph g=new MixedGraph();
        String[][] vs={
            {"S01","UAJS Sede C","Universidad"},{"S02","UAJS Sede E","Universidad"},
            {"S03","Universidad de Sucre","Universidad"},{"S04","CECAR","Universidad"},
            {"S05","Hospital Universitario","Salud"},{"S06","Clínica Las Américas","Salud"},
            {"S07","Estación Central SETP","Transporte"},{"S08","Terminal de Transporte","Transporte"},
            {"S09","Parque Santander","Punto de encuentro"},{"S10","Mercado de Sincelejo","Comercio"},
            {"S11","PEP Argelia","Paradero"},{"S12","Glorieta Sincelejito","Movilidad"}};
        for(String[] v:vs)g.addVertex(new Vertex(v[0],v[1],v[2]));
        add(g,"R01","S01","S07",4,"Corredor universitario",true);
        add(g,"R02","S07","S01",6,"Retorno por vía alterna",true);
        add(g,"R03","S01","S09",5,"Corredor peatonal",false);
        add(g,"R04","S02","S01",8,"Conexión entre sedes",false);
        add(g,"R05","S02","S06",10,"Ruta de atención",true);
        add(g,"R06","S06","S05",4,"Corredor clínico",true);
        add(g,"R07","S05","S09",6,"Vía hospitalaria",false);
        add(g,"R08","S09","S10",3,"Centro histórico",false);
        add(g,"R09","S10","S08",8,"Salida al terminal",true);
        add(g,"R10","S08","S10",9,"Ingreso desde terminal",true);
        add(g,"R11","S03","S12",4,"Corredor Puerta Roja",false);
        add(g,"R12","S12","S09",7,"Troncal al centro",false);
        add(g,"R13","S04","S11",6,"Conexión universitaria",false);
        add(g,"R14","S11","S07",8,"Ruta SETP al centro",true);
        add(g,"R15","S07","S09",3,"Transferencia central",false);
        add(g,"R16","S07","S08",12,"Ruta SETP al terminal",true);
        add(g,"R17","S09","S03",7,"Ruta hacia universidad",true);
        add(g,"R18","S12","S04",9,"Ruta hacia CECAR",true);
        return g;
    }
    private static void add(MixedGraph g,String id,String a,String b,int w,String label,boolean d){g.addEdge(new Edge(id,a,b,w,label,d));}
}

public class Edge {
    private final String id, label, from, to;
    private final int weight;
    private final boolean directed;
    public Edge(String id, String from, String to, int weight, String label, boolean directed) {
        if (id == null || id.isBlank() || from == null || to == null)
            throw new IllegalArgumentException("ID y extremos son obligatorios");
        if (weight <= 0) throw new IllegalArgumentException("El peso debe ser positivo");
        this.id=id; this.from=from; this.to=to; this.weight=weight;
        this.label=label == null ? "" : label; this.directed=directed;
    }
    public String getId(){return id;} public String getFrom(){return from;}
    public String getTo(){return to;} public int getWeight(){return weight;}
    public String getLabel(){return label;} public boolean isDirected(){return directed;}
    @Override public String toString(){return id+"("+from+(directed?" -> ":" -- ")+to+", "+weight+")";}
}

import java.util.*;

public class DijkstraSolver {
    public record Result(List<String> path,int cost,Map<String,Integer> distances) {}
    private record State(String id,int distance) {}
    public Result shortestPath(MixedGraph g,String start,String end){
        g.getVertex(start);g.getVertex(end);
        Map<String,Integer> dist=new HashMap<>();Map<String,String> prev=new HashMap<>();
        for(Vertex v:g.getVertices())dist.put(v.getId(),Integer.MAX_VALUE);
        dist.put(start,0);
        PriorityQueue<State> pq=new PriorityQueue<>(Comparator.comparingInt(State::distance));pq.add(new State(start,0));
        while(!pq.isEmpty()){
            State cur=pq.poll();if(cur.distance()!=dist.get(cur.id()))continue;if(cur.id().equals(end))break;
            for(Edge e:g.getOutgoing(cur.id())){String next=g.opposite(e,cur.id());long candidate=(long)cur.distance()+e.getWeight();
                if(candidate<dist.get(next)){dist.put(next,(int)candidate);prev.put(next,cur.id());pq.add(new State(next,(int)candidate));}
            }
        }
        if(dist.get(end)==Integer.MAX_VALUE)return new Result(List.of(),Integer.MAX_VALUE,Map.copyOf(dist));
        LinkedList<String> path=new LinkedList<>();String at=end;while(at!=null){path.addFirst(at);if(at.equals(start))break;at=prev.get(at);}
        return new Result(List.copyOf(path),dist.get(end),Map.copyOf(dist));
    }
}

# RedSegura — estructura sencilla

Proyecto Java 17 con Maven. Se organiza en solo dos carpetas de código:

- `src/`: todos los archivos `.java` de la aplicación.
- `test/`: pruebas JUnit 5.

No se utilizan declaraciones `package`; todos los archivos Java están en el paquete predeterminado. El `pom.xml` configura Maven para reconocer estas dos carpetas.

## Ejecutar
- Abrir la carpeta `RedSegura_Simple` como proyecto Maven en NetBeans.
- Ejecutar las pruebas con `mvn test`.
- Ejecutar `RedSeguraApplication.java` desde NetBeans.

## Componentes
Vertex, Edge, BinarySearchTree, AvlTree, MixedGraph, GraphRepresentations,
BreadthFirstSearch, DepthFirstSearch, DijkstraSolver, GraphFactory y
RedSeguraApplication.

Los algoritmos están implementados manualmente. La dependencia externa se usa únicamente para JUnit 5.
